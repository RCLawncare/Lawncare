'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, Calendar, DollarSign, AlertCircle } from 'lucide-react';

export function Dashboard() {
  const [stats] = useState({
    totalClients: 24,
    upcomingJobs: 8,
    monthlyRevenue: 4250,
    pendingPayments: 1850,
  });

  const revenueData = [
    { month: 'Jan', revenue: 2400 },
    { month: 'Feb', revenue: 2800 },
    { month: 'Mar', revenue: 3200 },
    { month: 'Apr', revenue: 3500 },
    { month: 'May', revenue: 3800 },
    { month: 'Jun', revenue: 4250 },
  ];

  const jobsData = [
    { week: 'W1', jobs: 6 },
    { week: 'W2', jobs: 8 },
    { week: 'W3', jobs: 5 },
    { week: 'W4', jobs: 9 },
  ];

  const upcomingJobs = [
    { id: 1, client: 'John Smith', service: 'Lawn Mow', date: '2025-01-20', status: 'Scheduled' },
    { id: 2, client: 'Sarah Johnson', service: 'Weeding & Fertilize', date: '2025-01-21', status: 'Scheduled' },
    { id: 3, client: 'Mike Davis', service: 'Hedge Trim', date: '2025-01-22', status: 'Scheduled' },
  ];

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's your business overview.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Clients</CardTitle>
          </CardHeader>
          <CardContent className="flex items-end justify-between">
            <div className="text-3xl font-bold text-foreground">{stats.totalClients}</div>
            <Users className="w-8 h-8 text-primary opacity-20" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Upcoming Jobs</CardTitle>
          </CardHeader>
          <CardContent className="flex items-end justify-between">
            <div className="text-3xl font-bold text-foreground">{stats.upcomingJobs}</div>
            <Calendar className="w-8 h-8 text-primary opacity-20" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent className="flex items-end justify-between">
            <div className="text-3xl font-bold text-foreground">${stats.monthlyRevenue}</div>
            <DollarSign className="w-8 h-8 text-primary opacity-20" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Payments</CardTitle>
          </CardHeader>
          <CardContent className="flex items-end justify-between">
            <div className="text-3xl font-bold text-destructive">${stats.pendingPayments}</div>
            <AlertCircle className="w-8 h-8 text-destructive opacity-20" />
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="revenue" stroke="oklch(0.48 0.24 142)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Jobs This Month</CardTitle>
            <CardDescription>By week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={jobsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="jobs" fill="oklch(0.65 0.2 142)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Jobs */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Jobs</CardTitle>
          <CardDescription>Next scheduled services</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingJobs.map((job) => (
              <div key={job.id} className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-foreground">{job.client}</p>
                  <p className="text-sm text-muted-foreground">{job.service}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground">{job.date}</p>
                  <p className="text-xs text-primary">{job.status}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
