'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, CheckCircle } from 'lucide-react';

interface ServiceRequest {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  service: string;
  date: string;
  status: 'New' | 'Accepted' | 'Rejected';
}

export function ServiceRequests() {
  const [requests, setRequests] = useState<ServiceRequest[]>([
    { id: 1, name: 'Robert Brown', email: 'robert@example.com', phone: '555-0104', address: '321 Elm St', service: 'Lawn Mow', date: '2025-01-22', status: 'New' },
    { id: 2, name: 'Emily Chen', email: 'emily@example.com', phone: '555-0105', address: '654 Maple Dr', service: 'Weed Control', date: '2025-01-23', status: 'New' },
    { id: 3, name: 'David Wilson', email: 'david@example.com', phone: '555-0106', address: '987 Cedar Ln', service: 'Landscaping', date: '2025-01-25', status: 'Accepted' },
  ]);

  const handleAccept = (id: number) => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: 'Accepted' as const } : r));
  };

  const handleReject = (id: number) => {
    setRequests(requests.filter(r => r.id !== id));
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Service Requests</h1>
        <p className="text-muted-foreground">Customer service requests from your public form</p>
      </div>

      <div className="space-y-3">
        {requests.map((request) => (
          <Card key={request.id} className={request.status === 'New' ? 'border-primary' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground text-lg">{request.name}</h3>
                    <span className={`text-xs px-2 py-1 rounded font-medium ${
                      request.status === 'New' ? 'bg-primary/10 text-primary' :
                      request.status === 'Accepted' ? 'bg-green-100 text-green-700' :
                      'bg-destructive/10 text-destructive'
                    }`}>
                      {request.status}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{request.email} • {request.phone}</p>
                  <p className="text-sm text-muted-foreground mt-1">{request.address}</p>
                  <div className="mt-3 p-3 bg-muted rounded">
                    <p className="text-sm"><span className="font-medium">Service:</span> {request.service}</p>
                    <p className="text-sm"><span className="font-medium">Preferred Date:</span> {request.date}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  {request.status === 'New' && (
                    <>
                      <Button size="sm" onClick={() => handleAccept(request.id)} className="gap-1">
                        <CheckCircle className="w-4 h-4" />
                        Accept
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleReject(request.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
