'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2, Edit2 } from 'lucide-react';

interface Client {
  id: number;
  name: string;
  phone: string;
  email: string;
  address: string;
  notes: string;
}

export function ClientManagement() {
  const [clients, setClients] = useState<Client[]>([
    { id: 1, name: 'John Smith', phone: '555-0101', email: 'john@example.com', address: '123 Main St', notes: 'Regular weekly service' },
    { id: 2, name: 'Sarah Johnson', phone: '555-0102', email: 'sarah@example.com', address: '456 Oak Ave', notes: 'Bi-weekly service' },
    { id: 3, name: 'Mike Davis', phone: '555-0103', email: 'mike@example.com', address: '789 Pine Rd', notes: 'Monthly maintenance' },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', address: '', notes: '' });

  const handleAdd = () => {
    if (formData.name && formData.phone) {
      if (editingId) {
        setClients(clients.map(c => c.id === editingId ? { ...formData, id: editingId } : c));
        setEditingId(null);
      } else {
        setClients([...clients, { ...formData, id: Date.now() }]);
      }
      setFormData({ name: '', phone: '', email: '', address: '', notes: '' });
      setShowForm(false);
    }
  };

  const handleEdit = (client: Client) => {
    setFormData(client);
    setEditingId(client.id);
    setShowForm(true);
  };

  const handleDelete = (id: number) => {
    setClients(clients.filter(c => c.id !== id));
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Clients</h1>
          <p className="text-muted-foreground">Manage your client relationships</p>
        </div>
        <Button onClick={() => { setShowForm(!showForm); setEditingId(null); setFormData({ name: '', phone: '', email: '', address: '', notes: '' }); }} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Client
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? 'Edit Client' : 'New Client'}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input placeholder="Client Name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
            <Input placeholder="Phone" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
            <Input placeholder="Email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
            <Input placeholder="Address" value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} />
            <Textarea placeholder="Notes" value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} />
            <div className="flex gap-2">
              <Button onClick={handleAdd}>{editingId ? 'Update' : 'Add'} Client</Button>
              <Button variant="outline" onClick={() => { setShowForm(false); setFormData({ name: '', phone: '', email: '', address: '', notes: '' }); }}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {clients.map((client) => (
          <Card key={client.id}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground text-lg">{client.name}</h3>
                  <p className="text-sm text-muted-foreground">{client.phone} • {client.email}</p>
                  <p className="text-sm text-muted-foreground mt-1">{client.address}</p>
                  {client.notes && <p className="text-sm text-foreground mt-2 italic">{client.notes}</p>}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleEdit(client)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => handleDelete(client.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
