'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

export function Settings() {
  const [settings, setSettings] = useState({
    businessName: 'RC Lawncare',
    ownerName: 'Your Name',
    phone: '385-418-6783', // updated phone number
    email: 'rclandscaping15@gmail.com', // updated email
    address: '1000 Business Ave',
    city: 'West Valley City', // updated city
    state: 'Utah', // updated state
    zipCode: '84128', // updated zip code
    bio: 'Professional lawncare and landscaping services',
    hourlyRate: '65',
  });

  const [isSaving, setIsSaving] = useState(false);

  const handleChange = (field: string, value: string) => {
    setSettings({ ...settings, [field]: value });
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      alert('Settings saved successfully!');
    }, 1000);
  };

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground">Manage your business information</p>
      </div>

      <div className="grid gap-6">
        {/* Business Information */}
        <Card>
          <CardHeader>
            <CardTitle>Business Information</CardTitle>
            <CardDescription>Update your business details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input label="Business Name" value={settings.businessName} onChange={(e) => handleChange('businessName', e.target.value)} />
              <Input label="Owner Name" value={settings.ownerName} onChange={(e) => handleChange('ownerName', e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Input label="Phone" value={settings.phone} onChange={(e) => handleChange('phone', e.target.value)} />
              <Input label="Email" value={settings.email} onChange={(e) => handleChange('email', e.target.value)} />
            </div>
            <Input label="Address" value={settings.address} onChange={(e) => handleChange('address', e.target.value)} />
            <div className="grid grid-cols-3 gap-4">
              <Input label="City" value={settings.city} onChange={(e) => handleChange('city', e.target.value)} />
              <Input label="State" value={settings.state} onChange={(e) => handleChange('state', e.target.value)} />
              <Input label="ZIP Code" value={settings.zipCode} onChange={(e) => handleChange('zipCode', e.target.value)} />
            </div>
          </CardContent>
        </Card>

        {/* Service Information */}
        <Card>
          <CardHeader>
            <CardTitle>Service Information</CardTitle>
            <CardDescription>Configure your services</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea label="Business Description" value={settings.bio} onChange={(e) => handleChange('bio', e.target.value)} />
            <Input label="Hourly Rate ($)" value={settings.hourlyRate} onChange={(e) => handleChange('hourlyRate', e.target.value)} />
          </CardContent>
        </Card>

        {/* Public Form URL */}
        <Card>
          <CardHeader>
            <CardTitle>Public Service Request Form</CardTitle>
            <CardDescription>Share this link with customers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input value="https://yourapp.com/request-service" readOnly />
              <Button variant="outline">Copy Link</Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Button onClick={handleSave} disabled={isSaving} className="w-full">
        {isSaving ? 'Saving...' : 'Save Settings'}
      </Button>
    </div>
  );
}
