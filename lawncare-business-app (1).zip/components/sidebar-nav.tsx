import { LayoutDashboard, Users, Calendar, FileText, DollarSign, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SidebarNavProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

export function SidebarNav({ activeView, setActiveView }: SidebarNavProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'requests', label: 'Requests', icon: FileText },
    { id: 'invoices', label: 'Invoices', icon: DollarSign },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-2xl font-bold text-sidebar-foreground">RC Lawncare</h1>
        <p className="text-sm text-sidebar-foreground/70">Business Management</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            variant={activeView === item.id ? 'default' : 'ghost'}
            className={`w-full justify-start gap-3 ${
              activeView === item.id
                ? 'bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary'
                : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
            }`}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </Button>
        ))}
      </nav>

      <div className="p-4 border-t border-sidebar-border text-sidebar-foreground/70 text-sm">
        <p>© 2025 RC Lawncare</p>
      </div>
    </aside>
  );
}
