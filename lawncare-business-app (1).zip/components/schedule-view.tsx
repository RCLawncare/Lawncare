'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash2 } from 'lucide-react';

interface ScheduledJob {
  id: number;
  date: string;
  time: string;
  client: string;
  service: string;
  status: 'Scheduled' | 'In Progress' | 'Completed';
}

export function ScheduleView() {
  const [jobs, setJobs] = useState<ScheduledJob[]>([
    { id: 1, date: '2025-01-20', time: '09:00', client: 'John Smith', service: 'Lawn Mow', status: 'Scheduled' },
    { id: 2, date: '2025-01-20', time: '11:00', client: 'Sarah Johnson', service: 'Weeding & Fertilize', status: 'Scheduled' },
    { id: 3, date: '2025-01-21', time: '10:00', client: 'Mike Davis', service: 'Hedge Trim', status: 'Scheduled' },
    { id: 4, date: '2025-01-19', time: '14:00', client: 'Jane Wilson', service: 'Cleanup', status: 'Completed' },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ date: '', time: '', client: '', service: '' });

  const handleAdd = () => {
    if (formData.date && formData.client && formData.service) {
      setJobs([...jobs, { ...formData, id: Date.now(), status: 'Scheduled' as const }]);
      setFormData({ date: '', time: '', client: '', service: '' });
      setShowForm(false);
    }
  };

  const handleStatusChange = (id: number, status: ScheduledJob['status']) => {
    setJobs(jobs.map(job => job.id === id ? { ...job, status } : job));
  };

  const handleDelete = (id: number) => {
    setJobs(jobs.filter(job => job.id !== id));
  };

  const groupedJobs = jobs.reduce((acc, job) => {
    if (!acc[job.date]) acc[job.date] = [];
    acc[job.date].push(job);
    return acc;
  }, {} as Record<string, ScheduledJob[]>);

  const sortedDates = Object.keys(groupedJobs).sort();

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Schedule</h1>
          <p className="text-muted-foreground">Manage your job schedule</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Job
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Schedule New Job</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
            <Input type="time" value={formData.time} onChange={(e) => setFormData({ ...formData, time: e.target.value })} />
            <Input placeholder="Client Name" value={formData.client} onChange={(e) => setFormData({ ...formData, client: e.target.value })} />
            <Input placeholder="Service Type" value={formData.service} onChange={(e) => setFormData({ ...formData, service: e.target.value })} />
            <div className="flex gap-2">
              <Button onClick={handleAdd}>Add Job</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-6">
        {sortedDates.map(date => (
          <div key={date}>
            <h2 className="text-lg font-semibold text-foreground mb-3">{new Date(date).toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</h2>
            <div className="space-y-3">
              {groupedJobs[date].map(job => (
                <Card key={job.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-semibold text-foreground">{job.time}</span>
                          <div>
                            <p className="font-medium text-foreground">{job.client}</p>
                            <p className="text-sm text-muted-foreground">{job.service}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <select
                          value={job.status}
                          onChange={(e) => handleStatusChange(job.id, e.target.value as ScheduledJob['status'])}
                          className="px-3 py-1 rounded border border-border bg-background text-foreground text-sm"
                        >
                          <option>Scheduled</option>
                          <option>In Progress</option>
                          <option>Completed</option>
                        </select>
                        <Button size="sm" variant="destructive" onClick={() => handleDelete(job.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
