'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash2, Download } from 'lucide-react';

interface Invoice {
  id: number;
  client: string;
  amount: number;
  date: string;
  dueDate: string;
  status: 'Paid' | 'Pending' | 'Overdue';
}

export function Invoices() {
  const [invoices, setInvoices] = useState<Invoice[]>([
    { id: 1, client: 'John Smith', amount: 150, date: '2025-01-10', dueDate: '2025-01-20', status: 'Paid' },
    { id: 2, client: 'Sarah Johnson', amount: 200, date: '2025-01-15', dueDate: '2025-01-25', status: 'Pending' },
    { id: 3, client: 'Mike Davis', amount: 175, date: '2025-01-05', dueDate: '2025-01-15', status: 'Overdue' },
    { id: 4, client: 'Jane Wilson', amount: 250, date: '2025-01-18', dueDate: '2025-01-28', status: 'Pending' },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ client: '', amount: '', dueDate: '' });

  const handleAdd = () => {
    if (formData.client && formData.amount && formData.dueDate) {
      setInvoices([...invoices, {
        id: Date.now(),
        client: formData.client,
        amount: parseFloat(formData.amount),
        date: new Date().toISOString().split('T')[0],
        dueDate: formData.dueDate,
        status: 'Pending'
      }]);
      setFormData({ client: '', amount: '', dueDate: '' });
      setShowForm(false);
    }
  };

  const handleMarkPaid = (id: number) => {
    setInvoices(invoices.map(inv => inv.id === id ? { ...inv, status: 'Paid' as const } : inv));
  };

  const handleDelete = (id: number) => {
    setInvoices(invoices.filter(inv => inv.id !== id));
  };

  const totalRevenue = invoices.filter(inv => inv.status === 'Paid').reduce((sum, inv) => sum + inv.amount, 0);
  const pendingAmount = invoices.filter(inv => inv.status === 'Pending').reduce((sum, inv) => sum + inv.amount, 0);

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Invoices & Payments</h1>
          <p className="text-muted-foreground">Track your invoices and payments</p>
        </div>
        <Button onClick={() => setShowForm(!showForm)} className="gap-2">
          <Plus className="w-4 h-4" />
          New Invoice
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue (Paid)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">${totalRevenue}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">${pendingAmount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Invoices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{invoices.length}</div>
          </CardContent>
        </Card>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create Invoice</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input placeholder="Client Name" value={formData.client} onChange={(e) => setFormData({ ...formData, client: e.target.value })} />
            <Input type="number" placeholder="Amount" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} />
            <Input type="date" label="Due Date" value={formData.dueDate} onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })} />
            <div className="flex gap-2">
              <Button onClick={handleAdd}>Create Invoice</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Invoices List */}
      <div className="space-y-3">
        {invoices.map((invoice) => (
          <Card key={invoice.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-semibold text-foreground">{invoice.client}</p>
                  <p className="text-sm text-muted-foreground">Invoice #{invoice.id} • {invoice.date}</p>
                  <p className="text-sm text-muted-foreground">Due: {invoice.dueDate}</p>
                </div>
                <div className="text-right mr-4">
                  <p className="text-lg font-bold text-foreground">${invoice.amount}</p>
                  <span className={`text-xs px-2 py-1 rounded font-medium inline-block mt-1 ${
                    invoice.status === 'Paid' ? 'bg-green-100 text-green-700' :
                    invoice.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-destructive/10 text-destructive'
                  }`}>
                    {invoice.status}
                  </span>
                </div>
                <div className="flex gap-2">
                  {invoice.status !== 'Paid' && (
                    <Button size="sm" variant="outline" onClick={() => handleMarkPaid(invoice.id)}>
                      Mark Paid
                    </Button>
                  )}
                  <Button size="sm" variant="outline">
                    <Download className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => handleDelete(invoice.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
