'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Menu, X, Phone, MapPin, Mail, CheckCircle, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <Leaf className="w-8 h-8 text-primary" />
              <span className="text-xl font-bold text-foreground">RC Lawncare</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex gap-8 items-center">
              <a href="#services" className="text-foreground hover:text-primary transition">Services</a>
              <a href="#about" className="text-foreground hover:text-primary transition">About</a>
              <a href="#contact" className="text-foreground hover:text-primary transition">Contact</a>
              <Link href="/request-service">
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Request Service
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline">Dashboard</Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 space-y-4">
              <a href="#services" className="block text-foreground hover:text-primary">Services</a>
              <a href="#about" className="block text-foreground hover:text-primary">About</a>
              <a href="#contact" className="block text-foreground hover:text-primary">Contact</a>
              <Link href="/request-service" className="block">
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                  Request Service
                </Button>
              </Link>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/95 to-primary/80 text-primary-foreground py-20 md:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
              Beautiful Lawns, Expert Care
            </h1>
            <p className="text-lg md:text-xl mb-8 text-primary-foreground/90 text-balance">
              Transform your outdoor space with professional lawn care services tailored to your needs. Serving West Valley City and surrounding areas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/request-service">
                <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground w-full sm:w-auto">
                  Get Free Quote
                </Button>
              </Link>
              <a href="tel:385-418-6783">
                <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 w-full sm:w-auto">
                  <Phone className="w-4 h-4 mr-2" />
                  Call Now
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Services</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Comprehensive lawn care solutions to keep your property looking its best year-round
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: 'Lawn Mowing', description: 'Regular maintenance and professional cutting' },
              { title: 'Landscaping', description: 'Design and installation of beautiful outdoor spaces' },
              { title: 'Edging & Trimming', description: 'Precise edging and weed trimming' },
              { title: 'Mulch Installation', description: 'Quality mulch for landscaping beds' },
              { title: 'Spring Cleanup', description: 'Seasonal preparation and maintenance' },
              { title: 'Yard Maintenance', description: 'Complete property upkeep and care' },
            ].map((service, idx) => (
              <div key={idx} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition">
                <div className="flex items-start gap-4">
                  <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-lg font-semibold text-card-foreground mb-2">{service.title}</h3>
                    <p className="text-muted-foreground">{service.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 md:py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Why Choose RC Lawncare?</h2>
              <ul className="space-y-4">
                {[
                  'Professional and reliable service',
                  'Attention to detail and quality work',
                  'Competitive and transparent pricing',
                  'Flexible scheduling options',
                  'Fully insured and licensed',
                  'Local business serving West Valley City',
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-primary/10 rounded-lg aspect-video flex items-center justify-center">
              <Leaf className="w-24 h-24 text-primary/20" />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Get in Touch</h2>
            <p className="text-lg text-muted-foreground">We'd love to hear from you. Reach out today!</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-card border border-border rounded-lg p-6 text-center">
              <Phone className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Phone</h3>
              <a href="tel:385-418-6783" className="text-primary hover:underline">
                385-418-6783
              </a>
            </div>

            <div className="bg-card border border-border rounded-lg p-6 text-center">
              <Mail className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Email</h3>
              <a href="mailto:rclandscaping15@gmail.com" className="text-primary hover:underline">
                rclandscaping15@gmail.com
              </a>
            </div>

            <div className="bg-card border border-border rounded-lg p-6 text-center">
              <MapPin className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Location</h3>
              <p className="text-muted-foreground">
                West Valley City, Utah 84128
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link href="/request-service">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Request Service Online
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary/95 text-primary-foreground py-12 border-t border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Leaf className="w-6 h-6" />
                <span className="font-bold">RC Lawncare</span>
              </div>
              <p className="text-primary-foreground/80 text-sm">
                Professional lawn care services in West Valley City, Utah.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#services" className="hover:underline">Services</a></li>
                <li><a href="#about" className="hover:underline">About</a></li>
                <li><a href="#contact" className="hover:underline">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="tel:385-418-6783" className="hover:underline">385-418-6783</a></li>
                <li><a href="mailto:rclandscaping15@gmail.com" className="hover:underline">rclandscaping15@gmail.com</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Service Area</h4>
              <p className="text-sm">West Valley City, Utah 84128</p>
            </div>
          </div>

          <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm text-primary-foreground/80">
            <p>&copy; 2025 RC Lawncare. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
