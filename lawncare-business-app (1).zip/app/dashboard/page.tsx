'use client';

import { useState } from 'react';
import { Dashboard } from '@/components/dashboard';
import { ClientManagement } from '@/components/client-management';
import { ScheduleView } from '@/components/schedule-view';
import { ServiceRequests } from '@/components/service-requests';
import { Invoices } from '@/components/invoices';
import { Settings } from '@/components/settings';
import { SidebarNav } from '@/components/sidebar-nav';

export default function DashboardPage() {
  const [activeView, setActiveView] = useState('dashboard');

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'clients':
        return <ClientManagement />;
      case 'schedule':
        return <ScheduleView />;
      case 'requests':
        return <ServiceRequests />;
      case 'invoices':
        return <Invoices />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-background">
      <SidebarNav activeView={activeView} setActiveView={setActiveView} />
      <main className="flex-1 overflow-auto">
        {renderView()}
      </main>
    </div>
  );
}
